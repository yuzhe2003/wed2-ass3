// admin.js

function loadFundraisers() {
    fetch('https://24274465.it.scu.edu.au/api/fundraisers')
      .then(response => response.json())
      .then(data => {
        const fundraisersTableBody = document.getElementById('fundraisersTableBody');
        fundraisersTableBody.innerHTML = ''; // Clear previous entries
        data.forEach(fundraiser => {
          const row = document.createElement('tr');
          row.innerHTML = `
            <td>${fundraiser.FUNDRAISER_ID}</td>
            <td>${fundraiser.ORGANIZER}</td>
            <td>${fundraiser.CAPTION}</td>
            <td>${fundraiser.TARGET_FUNDING} AUD</td>
            <td>${fundraiser.CURRENT_FUNDING} AUD</td>
            <td>${fundraiser.CITY}</td>
            <td>${fundraiser.active == '1' ? 'Active' : 'Inactive'}</td>
            <td>
              <button class="edit-btn" onclick="loadFundraiserDetails(${fundraiser.FUNDRAISER_ID})">Edit</button>
              <button class="delete-btn" onclick="deleteFundraiser(${fundraiser.FUNDRAISER_ID})">Delete</button>
            </td>
          `;
          fundraisersTableBody.appendChild(row);
        });
      })
      .catch(error => console.error('Error loading fundraisers:', error));
  }
  
  function loadCategories() {
    fetch('https://24274465.it.scu.edu.au/api/categories')
      .then(response => response.json())
      .then(data => {
        const categorySelect = document.getElementById('CATEGORY_ID');
        const categorySelectUpdate = document.getElementById('CATEGORY_IDUpdate');
        categorySelect.innerHTML = '';
        categorySelectUpdate.innerHTML = '';
        data.forEach(category => {
          const option = document.createElement('option');
          option.value = category.CATEGORY_ID;
          option.textContent = category.NAME;
          categorySelect.appendChild(option);
          const optionUpdate = document.createElement('option');
          optionUpdate.value = category.CATEGORY_ID;
          optionUpdate.textContent = category.NAME;
          categorySelectUpdate.appendChild(optionUpdate);
        });
      })
      .catch(error => console.error('Error loading categories:', error));
  }
  
  function createNewFundraiser() {
    const createFundraiserForm = document.getElementById('createFundraiserForm');
    const formData = new FormData(createFundraiserForm);
    const fundraiserData = {};
    formData.forEach((value, key) => {
      if (key !== 'CATEGORY_ID') {
        fundraiserData[key] = value;
      } else {
        fundraiserData[key] = parseInt(value, 10);
      }
    });
  
    fetch('https://24274465.it.scu.edu.au/api/fundraiser', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(fundraiserData)
    })
      .then(response => {
        if (!response.ok) {
          throw new Error('Failed to create fundraiser.');
        }
        return response.json();
      })
      .then(data => {
        location.reload();
      })
      .catch(error => console.error('Error creating fundraiser:', error));
  }
  
  function loadFundraiserDetails(id) {
    fetch(`https://24274465.it.scu.edu.au/api/fundraiser/${id}`)
      .then(response => response.json())
      .then(data => {
        const fundraiser = data;
        Object.keys(fundraiser).forEach(key => {
          if (key !== 'FUNDRAISER_ID' && key !== 'category_name' && key != 'donations' && key!='AMOUNT' && key!='GIVER'&& key!='DONATION_ID'&& key!= 'DATE') {
            document.getElementById(`${key}Update`).value = fundraiser[key];
          }
        });
        document.getElementById('fundraiserId').value = id;
        // Display donations if needed
      })
      .catch(error => console.error('Error loading fundraiser details:', error));
  }
  
  function updateFundraiser() {
    const updateFundraiserForm = document.getElementById('updateFundraiserForm');
    const id = document.getElementById('fundraiserId').value;
    const formData = [{
        "ORGANIZER":document.getElementById(`ORGANIZERUpdate`).value,
        "CAPTION":document.getElementById(`CAPTIONUpdate`).value,
        "TARGET_FUNDING":document.getElementById(`TARGET_FUNDINGUpdate`).value,
        "CURRENT_FUNDING":document.getElementById(`CURRENT_FUNDINGUpdate`).value,
        "CITY":document.getElementById(`CITYUpdate`).value,
        "ACTIVE":document.getElementById(`ACTIVEUpdate`).value,
        "CATEGORY_ID":document.getElementById(`CATEGORY_IDUpdate`).value,
    }];
    console.log(formData);

    const fundraiserData = {};
    formData.forEach((value, key) => {
      if (key !== 'FUNDRAISER_ID') {
        fundraiserData[key] = value;
      }
    });
  
    fetch(`https://24274465.it.scu.edu.au/api/fundraiser/${id}`, {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(fundraiserData)
    })
      .then(response => {
        if (!response.ok) {
          throw new Error('Failed to update fundraiser.');
        }
        return response.json();
      })
      .then(data => {
        location.reload();
      })
      .catch(error => console.error('Error updating fundraiser:', error));
  }
  
  function deleteFundraiser(id) {
    if (confirm('Are you sure you want to delete this fundraiser?')) {
      fetch(`https://24274465.it.scu.edu.au/api/fundraiser/${id}`, {
        method: 'DELETE'
      })
        .then(response => {
          if (!response.ok) {
            throw new Error('Failed to delete fundraiser.');
          }
          return response.json();
        })
        .then(data => {
          location.reload();
        })
        .catch(error => console.error('Error deleting fundraiser:', error));
    }
  }
  
  document.addEventListener('DOMContentLoaded', function() {
    loadFundraisers();
    loadCategories();
  
    const createFundraiserForm = document.getElementById('createFundraiserForm');
    createFundraiserForm.addEventListener('submit', function(event) {
      event.preventDefault();
      createNewFundraiser();
    });
  
    const updateFundraiserForm = document.getElementById('updateFundraiserForm');
    updateFundraiserForm.addEventListener('submit', function(event) {
      event.preventDefault();
      updateFundraiser();
    });
  });