document.addEventListener('DOMContentLoaded', function() {
  const fundraiserDetails = document.getElementById('fundraiserDetails');
  const donateButton = document.getElementById('donateButton');
  const donationsList = document.getElementById('donationsList');

  loadFundraiserPage();

  // Add event listeners to the navigation links
  const navLinks = document.querySelectorAll('nav ul li a');
  navLinks.forEach(link => {
    link.addEventListener('click', function(event) {
      event.preventDefault();
      const page = this.getAttribute('href');
      window.location.href = page;
    });
  });

  function loadFundraiserPage() {
    const id = new URLSearchParams(window.location.search).get('id');
    
    if (!id) return;

    fetch(`https://24274465.it.scu.edu.au/api/fundraiser/${id}`)
      .then(response => response.json())
      .then(data => {
        fundraiserDetails.innerHTML = `
          <h2>${data.CAPTION}</h2>
          <p><strong>ID:</strong> ${data.FUNDRAISER_ID}</p>
          <p><strong>Organiser:</strong> ${data.ORGANIZER}</p>
          <p><strong>Target Funding:</strong> ${data.TARGET_FUNDING} AUD</p>
          <p><strong>Current Funding:</strong> ${data.CURRENT_FUNDING} AUD</p>
          <p><strong>City:</strong> ${data.CITY}</p>
          <p><strong>Category:</strong> ${data.category_name}</p>
          <p><strong>Status:</strong> ${data.active == '1' ? 'Active' : 'Suspended'}</p>
        `;

        // Display Donations List
        displayDonations(data.donations);
      })
      .catch(error => {
        fundraiserDetails.innerHTML = `<p>Error loading fundraiser details: ${error.message}</p>`;
      });

    donateButton.addEventListener('click', function() {
      // Redirect to Donation page
      window.location.href = 'donation.html?id=' + id;
    });
  }

  function displayDonations(donations) {
    if (donations && donations.length > 0) {
      const donationsHTML = donations.map(donation => `
        <div class="donation-item">
          <p><strong>Date:</strong> ${donation.DATE}</p>
          <p><strong>Amount:</strong> ${donation.AMOUNT} AUD</p>
          <p><strong>Giver:</strong> ${donation.GIVER}</p>
        </div>`).join('');
      donationsList.innerHTML = donationsHTML;
    } else {
      donationsList.innerHTML = '<p>No donations available.</p>';
    }
  }
});