
document.addEventListener('DOMContentLoaded', function() {
    const contentDiv = document.getElementById('content');
    console.log('contentDiv',contentDiv)

    const searchResults = document.getElementById('searchResults');
    const errorMessage = document.getElementById('errorMessage');
    const clearButton = document.getElementById('clearButton');
    const searchForm = document.getElementById('searchForm');
    console.log('searchForm',searchForm)
    const searchButton = document.getElementById('searchButton');
    const donateButton = document.getElementById('donateButton');
    const fundraiserDetails = document.getElementById('fundraiserDetails');
  
    loadSearchPage();

    // Add event listeners to the navigation links
    const navLinks = document.querySelectorAll('nav ul li a');
    navLinks.forEach(link => {
      link.addEventListener('click', function(event) {
        event.preventDefault();
        const page = this.getAttribute('href');
        window.location.href = page;
        loadPage(page);
        flag = "111"
        console.log(flag)
      });
    });
  
  
    function loadSearchPage() {
        const searchResults = document.getElementById('searchResults');
        const searchForm = document.getElementById('searchForm');
        const errorMessage = document.getElementById('errorMessage');
      searchForm.addEventListener('submit', function(event) {
        event.preventDefault();
        const organizer = document.getElementById('organizer').value;
        const city = document.getElementById('city').value;
        const category = document.getElementById('category').value;
  
        if (!organizer && !city && !category) {
          errorMessage.style.display = 'block';
          errorMessage.textContent = 'Please select at least one criteria.';
          return;
        }
  
        errorMessage.style.display = 'none';
        
        searchResults.innerHTML = '';
  
        let query = '';
        if (organizer) query += `&organizer=${organizer}`;
        if (city) query += `&city=${city}`;
        if (category) query += `&category=${category}`;
        
        query.replace("20%"," ");
        console.log(`https://24274465.it.scu.edu.au/api/search?${query.slice(1)}`)

        fetch(`https://24274465.it.scu.edu.au/api/search?${query.slice(1)}`)
          .then(response => response.json())
          .then(data => {
            if (data.length === 0) {
              errorMessage.style.display = 'block';
              errorMessage.textContent = 'No fundraisers found.';
            } else {
              searchResults.innerHTML = `
                <div class="fundraisers-list">
                  ${data.map(fundraiser => `
                    <div class="fundraiser">
                      <img src="img/logo.png" alt="${fundraiser.CAPTION}">
                      <h3>${fundraiser.CAPTION}</h3>
                      <p><strong>ID:</strong> ${fundraiser.FUNDRAISER_ID}</p>
                      <p><strong>Organiser:</strong> ${fundraiser.ORGANIZER}</p>
                      <p><strong>Target Funding:</strong> ${fundraiser.TARGET_FUNDING} AUD</p>
                      <p><strong>Current Funding:</strong> ${fundraiser.CURRENT_FUNDING} AUD</p>
                      <p><strong>City:</strong> ${fundraiser.CITY}</p>
                      <p><strong>Category:</strong> ${fundraiser.category_name}</p>
                      <p><strong>Status:</strong> ${fundraiser.active == '1' ? 'Active' : 'Suspended'}</p>
                      <a href="fundraiser.html?id=${fundraiser.FUNDRAISER_ID}">View Details</a>
                    </div>
                  `).join('')}
                </div>
              `;
            }
          })
          .catch(error => {
            errorMessage.style.display = 'block';
            errorMessage.textContent = `Error loading fundraisers: ${error.message}`;
          });
      });
  
      clearButton.addEventListener('click', function() {
        clearCheckboxes();
      });
  
      function clearCheckboxes() {
        document.getElementById('organizer').value = '';
        document.getElementById('city').value = '';
        document.getElementById('category').value = '';
      }
    }
  
  
    function loadPage(page) {
      switch (page) {
        case 'index.html':
          loadHomePage();
          break;
        case 'search.html':
            setTimeout(() => {
          loadSearchPage();
            }, 2000);
          break;
        case 'fundraiser.html':
          loadFundraiserPage();
          break;
        case 'about.html':
          // Implement about page here
          contentDiv.innerHTML = '<h2>Task made by XXX</h2>';
          break;
        default:
          contentDiv.innerHTML = '<h2>Unknown Page</h2>';
      }
    }
  });