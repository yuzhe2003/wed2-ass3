document.addEventListener('DOMContentLoaded', function() {
    const donationForm = document.getElementById('donationForm');
    const submitDonation = document.getElementById('submitDonation');
    const messageBox = document.getElementById('messageBox');
    const fundraiserInfo = document.getElementById('fundraiserInfo');

    const id = new URLSearchParams(window.location.search).get('id');

    if (!id) {
      messageBox.textContent = 'No fundraiser selected.';
      return;
    }

    loadFundraiserInfo(id);

    donationForm.addEventListener('submit', function(event) {
      event.preventDefault();

      const amount = parseFloat(document.getElementById('amount').value);
      const giver = document.getElementById('giver').value;

      if (amount < 5) {
        messageBox.textContent = 'The minimum donation amount is 5 AUD.';
        return;
      }

      submitDonation1();
    });

    function loadFundraiserInfo(id) {
      fetch(`https://24274465.it.scu.edu.au/api/fundraiser/${id}`)
        .then(response => response.json())
        .then(data => {
          fundraiserInfo.innerHTML = `
            <h2>${data.CAPTION}</h2>
            <p><strong>ID:</strong> ${data.FUNDRAISER_ID}</p>
            <p><strong>Organiser:</strong> ${data.ORGANIZER}</p>
            <p><strong>Target Funding:</strong> ${data.TARGET_FUNDING} AUD</p>
            <p><strong>Current Funding:</strong> ${data.CURRENT_FUNDING} AUD</p>
            <p><strong>City:</strong> ${data.CITY}</p>
            <p><strong>Category:</strong> ${data.category_name}</p>
            <p><strong>Status:</strong> ${data.active == '1' ? 'Active' : 'Suspended'}</p>
          `;
        })
        .catch(error => {
          messageBox.textContent = `Error loading fundraiser details: ${error.message}`;
        });
    }

    async function submitDonation1() {
      const amount = parseFloat(document.getElementById('amount').value);
      const giver = document.getElementById('giver').value;
      const id = new URLSearchParams(window.location.search).get('id');

      try {
        const response = await fetch('https://24274465.it.scu.edu.au/api/donation', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({ amount, giver, fundraiser_id: id })
        });

        if (!response.ok) {
          throw new Error('Failed to insert donation.');
        }

        messageBox.textContent = `Thank you for your donation to ${document.querySelector('#fundraiserInfo h2').textContent}`;
        setTimeout(() => {
          window.location.href = `fundraiser.html?id=${id}`;
        }, 2000);
      } catch (error) {
        messageBox.textContent = `An error occurred: ${error.message}`;
      }
    }
});