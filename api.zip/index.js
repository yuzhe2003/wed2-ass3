const express = require('express');
const app = express();
const path = require('path');
const router = require('./routes');

// Using JSON body parsing middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Set static folder
app.use(express.static('public'));

// Using Routing
app.use('/api', router);

// Set up ports and start the server
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));