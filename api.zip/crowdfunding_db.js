const mysql = require('mysql');

// Create a connection object
const db = mysql.createConnection({
  host: 'localhost',
  user: 'jtian11_jtian11',
  password: 'Jiaxuj0417.',
  database: 'jtian11_crowdfunding_db'
});

// Connect to the database
db.connect((err) => {
  if (err) throw err;
  console.log('Connected!');
});


module.exports = db;