/*
 Navicat Premium Data Transfer

 Source Server         : 本地mysql
 Source Server Type    : MySQL
 Source Server Version : 80035
 Source Host           : localhost:3306
 Source Schema         : crowdfunding_db

 Target Server Type    : MySQL
 Target Server Version : 80035
 File Encoding         : 65001

 Date: 13/10/2024 17:42:40
*/

SET NAMES utf8;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for category
-- ----------------------------
DROP TABLE IF EXISTS `category`;
CREATE TABLE `category`  (
  `CATEGORY_ID` int NOT NULL AUTO_INCREMENT,
  `NAME` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  PRIMARY KEY (`CATEGORY_ID`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 5 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of category
-- ----------------------------
INSERT INTO `category` VALUES (1, 'Health');
INSERT INTO `category` VALUES (2, 'Education');
INSERT INTO `category` VALUES (3, 'Environment');
INSERT INTO `category` VALUES (4, 'Arts');
INSERT INTO `category` VALUES (5, 'Technology');

-- ----------------------------
-- Table structure for donation
-- ----------------------------
DROP TABLE IF EXISTS `donation`;
CREATE TABLE `donation`  (
  `DONATION_ID` int NOT NULL AUTO_INCREMENT,
  `DATE` datetime NULL DEFAULT CURRENT_TIMESTAMP,
  `AMOUNT` decimal(10, 2) NOT NULL,
  `GIVER` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `FUNDRAISER_ID` int NULL DEFAULT NULL,
  PRIMARY KEY (`DONATION_ID`) USING BTREE,
  INDEX `FUNDRAISER_ID`(`FUNDRAISER_ID`) USING BTREE,
  CONSTRAINT `donation_ibfk_1` FOREIGN KEY (`FUNDRAISER_ID`) REFERENCES `fundraiser` (`FUNDRAISER_ID`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 11 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of donation
-- ----------------------------
INSERT INTO `donation` VALUES (1, '2024-10-13 14:23:52', 500.00, 'John Doe', 1);
INSERT INTO `donation` VALUES (2, '2024-10-13 14:23:52', 200.00, 'Jane Smith', 2);
INSERT INTO `donation` VALUES (3, '2024-10-13 14:23:52', 300.00, 'Alice Johnson', 3);
INSERT INTO `donation` VALUES (4, '2024-10-13 14:23:52', 150.00, 'Bob Lee', 4);
INSERT INTO `donation` VALUES (5, '2024-10-13 14:23:52', 250.00, 'Carolyn White', 5);
INSERT INTO `donation` VALUES (6, '2024-10-13 14:23:52', 350.00, 'David Brown', 6);
INSERT INTO `donation` VALUES (7, '2024-10-13 14:23:52', 100.00, 'Eva Green', 7);
INSERT INTO `donation` VALUES (8, '2024-10-13 14:23:52', 400.00, 'Frank Black', 8);
INSERT INTO `donation` VALUES (9, '2024-10-13 14:23:52', 120.00, 'Grace Grey', 9);
INSERT INTO `donation` VALUES (10, '2024-10-13 14:23:52', 180.00, 'Henry Harris', 10);
INSERT INTO `donation` VALUES (11, '2024-10-13 15:36:16', 13.00, 'zxz', 1);
INSERT INTO `donation` VALUES (12, '2024-10-13 17:19:06', 1212.00, 'zxz', 1);

-- ----------------------------
-- Table structure for fundraiser
-- ----------------------------
DROP TABLE IF EXISTS `fundraiser`;
CREATE TABLE `fundraiser`  (
  `FUNDRAISER_ID` int NOT NULL AUTO_INCREMENT,
  `ORGANIZER` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `CAPTION` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `TARGET_FUNDING` decimal(10, 2) NOT NULL,
  `CURRENT_FUNDING` decimal(10, 2) NOT NULL,
  `CITY` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `ACTIVE` tinyint(1) NOT NULL,
  `CATEGORY_ID` int NULL DEFAULT NULL,
  PRIMARY KEY (`FUNDRAISER_ID`) USING BTREE,
  INDEX `CATEGORY_ID`(`CATEGORY_ID`) USING BTREE,
  CONSTRAINT `fundraiser_ibfk_1` FOREIGN KEY (`CATEGORY_ID`) REFERENCES `category` (`CATEGORY_ID`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 10 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of fundraiser
-- ----------------------------
INSERT INTO `fundraiser` VALUES (1, 'Alice Johnson', 'Help local children get education supplies', 5000.00, 2500.00, 'New York', 1, 2);
INSERT INTO `fundraiser` VALUES (2, 'Bob Smith', 'Fund medical treatment for sick pets', 3000.00, 1500.00, 'Los Angeles', 1, 1);
INSERT INTO `fundraiser` VALUES (3, 'Charlie Brown', 'Plant trees in urban areas', 10000.00, 7000.00, 'San Francisco', 1, 3);
INSERT INTO `fundraiser` VALUES (4, 'Diana Prince', 'Support community health initiatives', 8000.00, 6000.00, 'Chicago', 1, 1);
INSERT INTO `fundraiser` VALUES (5, 'Ethan Hunt', 'Provide scholarships for underprivileged students', 20000.00, 12000.00, 'Miami', 1, 2);
INSERT INTO `fundraiser` VALUES (6, 'Fiona Green', 'Art therapy for mental health', 4000.00, 2000.00, 'Seattle', 1, 4);
INSERT INTO `fundraiser` VALUES (7, 'George White', 'Tech equipment for schools', 15000.00, 8000.00, 'Austin', 1, 5);
INSERT INTO `fundraiser` VALUES (8, 'Hannah Blue', 'Wildlife conservation project', 12000.00, 9000.00, 'Denver', 1, 3);
INSERT INTO `fundraiser` VALUES (9, 'Ian Black', 'Music classes for youth', 6000.00, 3500.00, 'Boston', 1, 4);
INSERT INTO `fundraiser` VALUES (10, 'Jenna Gold', 'Support STEM education programs', 10000.00, 5000.00, 'Atlanta', 1, 2);
INSERT INTO `fundraiser` VALUES (20, '123', '123', 123.00, 132.00, '1321', 1, 1);

SET FOREIGN_KEY_CHECKS = 1;
