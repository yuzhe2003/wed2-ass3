const express = require('express');
const router = express.Router();
const db = require('./crowdfunding_db');

// Get all active fundraising activities
router.get('/fundraisers', (req, res) => {
  const sql = `
    SELECT * FROM fundraiser`;
  db.query(sql, (err, results) => {
    if (err) {
      console.error(err);
      res.status(500).send('Server error');
    } else {
      res.json(results);
    }
  });
});

// Obtain category
router.get('/', (req, res) => {
  const sql = 'SELECT * FROM fundraiser';
  db.query(sql, (err, results) => {
    if (err) {
      console.error(err);
      res.status(500).send('Server error');
    } else {
      res.json(results);
    }
  });
});
// Obtain category
router.get('/categories', (req, res) => {
  const sql = 'SELECT * FROM category';
  db.query(sql, (err, results) => {
    if (err) {
      console.error(err);
      res.status(500).send('Server error');
    } else {
      res.json(results);
    }
  });
});

//   Search for Fundraising Activities
router.get('/search', (req, res) => {
  const { organizer, city, category } = req.query;
  let sql = `
    SELECT F.*, C.name AS category_name
    FROM fundraiser F
    JOIN CATEGORY C ON F.category_id = C.CATEGORY_ID
    WHERE F.ACTIVE = '1'
  `;
  const conditions = [];
  if (organizer) {
    conditions.push(`F.organizer LIKE '%${organizer}%'`);
  }
  if (city) {
    conditions.push(`F.city LIKE '%${city}%'`);
  }
  if (category) {
    conditions.push(`C.name LIKE '%${category}%'`);
  }
  if (conditions.length > 0) {
    sql += ' AND ' + conditions.join(' AND ');
  }
  db.query(sql, (err, results) => {
    if (err) {
      console.error(err);
      res.status(500).send('Server error');
    } else {
      res.json(results);
    }
  });
});

router.get('/fundraiser/:id', (req, res) => {
  const id = req.params.id;
  const sql = `
    SELECT F.*, C.name AS category_name, D.*
    FROM fundraiser F
    JOIN CATEGORY C ON F.category_id = C.CATEGORY_ID
    LEFT JOIN DONATION D ON F.fundraiser_id = D.fundraiser_id
    WHERE F.FUNDRAISER_ID = ?
  `;
  db.query(sql, [id], (err, results) => {
    if (err) {
      console.error(err);
      res.status(500).send('Server error');
    } else if (results.length === 0) {
      res.status(404).send('No fundraiser found with the given ID.');
    } else {
      // Separate donation data from query results
      console.log(results);
      
      const fundraiser = results[0];
      const donations = results.filter(result => result.DONATION_ID !== undefined);
      res.json({ ...fundraiser, donations });
    }
  });
});

router.post('/donation', (req, res) => {
  const { amount, giver, fundraiser_id } = req.body;
  const sql = 'INSERT INTO DONATION (AMOUNT, GIVER, FUNDRAISER_ID) VALUES (?, ?, ?);';
  db.query(sql, [amount, giver, fundraiser_id], (err, results) => {
    if (err) {
      console.error(err);
      res.status(500).send('Server error');
    } else {
      res.status(201).json({ message: 'Donation created successfully' });
    }
  });
});

router.post('/fundraiser', (req, res) => {
  const { organizer, caption, target_funding, current_funding, city, active, CATEGORY_ID } = req.body;
  console.log(req.body);
  const sql = `
    INSERT INTO fundraiser (ORGANIZER, CAPTION, TARGET_FUNDING, CURRENT_FUNDING, CITY, ACTIVE, CATEGORY_ID)
    VALUES (?, ?, ?, ?, ?, ?, ?);
  `;
  db.query(sql, [organizer, caption, target_funding, current_funding, city, active, CATEGORY_ID], (err, results) => {
    if (err) {
      console.error(err);
      res.status(500).send('Server error');
    } else {
      res.status(201).json({ message: 'Fundraiser created successfully' });
    }
  });
});

router.put('/fundraiser/:id', (req, res) => {
  const id = req.params.id;
  console.log((req.body)[0]);
  
  const { ORGANIZER, CAPTION, TARGET_FUNDING, CURRENT_FUNDING, CITY, ACTIVE, CATEGORY_ID } = (req.body)[0];
  const sql = `
    UPDATE fundraiser SET ORGANIZER = ?, CAPTION = ?, TARGET_FUNDING = ?, CURRENT_FUNDING = ?, CITY = ?, ACTIVE = ?, CATEGORY_ID = ?
    WHERE FUNDRAISER_ID = ?;
  `;
  db.query(sql, [ORGANIZER, CAPTION, TARGET_FUNDING, CURRENT_FUNDING, CITY, ACTIVE, CATEGORY_ID, id], (err, results) => {
    if (err) {
      console.error(err);
      res.status(500).send('Server error');
    } else if (results.affectedRows === 0) {
      res.status(404).send('No fundraiser found with the given ID.');
    } else {
      res.json({ message: 'Fundraiser updated successfully' });
    }
  });
});

router.delete('/fundraiser/:id', (req, res) => {
  const id = req.params.id;
  const checkSql = 'SELECT COUNT(*) AS count FROM DONATION WHERE FUNDRAISER_ID = ?;';
  db.query(checkSql, [id], (err, result) => {
    if (err) {
      console.error(err);
      res.status(500).send('Server error');
    } else if (result[0].count > 0) {
      res.status(400).send('Cannot delete fundraiser because there are associated donations.');
    } else {
      const deleteSql = 'DELETE FROM fundraiser WHERE FUNDRAISER_ID = ?;';
      db.query(deleteSql, [id], (err, results) => {
        if (err) {
          console.error(err);
          res.status(500).send('Server error');
        } else if (results.affectedRows === 0) {
          res.status(404).send('No fundraiser found with the given ID.');
        } else {
          res.json({ message: 'Fundraiser deleted successfully' });
        }
      });
    }
  });
});

module.exports = router;